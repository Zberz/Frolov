package list7;

class listing7_2{

}
