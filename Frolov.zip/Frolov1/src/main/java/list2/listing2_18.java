package list2;

class AlphabetDoWhileDemo {
    public static void main(String[] args) {
        char ch = 'Я';
        do {
            System.out.println(ch);
            ch--;
        } while (ch >= 'A');

    } // main(String[])

} // AlphabetDoWhileDemo class
