package list2;

class StrDemo {
    public static void main(String[] args){

        //для перевода каретки(начало новой строки)
        //служит код \n
        System.out.println("Первая строка\nВторая строка");

        //нак тамбуляции помогает оформить выводный текст
        //в колонки. Он выводится с помощью кода \t
        System.out.println("A\tB\tC");
        System.out.println("D\tE\tF");

    }//main(String[] method
}//StrDemo class
